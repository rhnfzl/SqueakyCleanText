from pathlib import Path
import json,hashlib,subprocess,datetime,tarfile
root=Path('/home/rehan/sct-gpu-supported-20261110')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[p for p in root.iterdir() if p.is_file() and (p.suffix in ('.py','.json','.log','.exit','.txt') or p.name.startswith('requirements'))]
paths += [p for p in (root/'gpu-results').iterdir() if p.is_file()]
paths += [root/'scripts/qualify_gpu.py']
paths += [Path('/home/rehan/sct-improvements-r1-models-20261107/model-artifacts.json')]
source={str(p.relative_to(root)):sha(p) for p in sorted((root/'sct').rglob('*.py'))}
freeze=subprocess.check_output(['uv','pip','freeze','--python',str(root/'.venv/bin/python')],text=True)
(root/'gpu-freeze.txt').write_text(freeze);paths.append(root/'gpu-freeze.txt')
record={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':source,'files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(set(paths))},'gpu_after':subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,driver_version,memory.total,memory.used,utilization.gpu','--format=csv,noheader'],text=True),'processes_after':subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader'],text=True)}
(root/'gpu-evidence-inventory.json').write_text(json.dumps(record,indent=2)+'\n')
# Compact durable QA bundle; large traces stay on gpuserver with recorded hashes.
small=[p for p in paths if p.stat().st_size<250000 and 'trace' not in p.name and not p.name.startswith(('ort-','quality-ort','corpus-ort','runtime-smoke_'))]
with tarfile.open(root/'gpu-evidence-small.tar.gz','w:gz') as archive:
 for p in sorted(set(small)):
  name=str(p.relative_to(root)) if p.is_relative_to(root) else 'quality-model-artifacts.json'
  archive.add(p,arcname=name,recursive=False)
 archive.add(root/'gpu-evidence-inventory.json',arcname='gpu-evidence-inventory.json')
print(len(source),'source files',len(paths),'evidence files; bundle',sha(root/'gpu-evidence-small.tar.gz'))
