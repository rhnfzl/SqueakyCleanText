from pathlib import Path
import hashlib,json,os,socket,gc,sys
import torch,numpy as np,onnxruntime as ort
from transformers import AutoModel,AutoTokenizer
from scripts.export_quality_head import QualityModel
from sct.score import ONNXQualityScorer,ScoreConfig
from sct import TextCleaner,TextCleanerConfig,DetectorSpec
from sct.corpus import CorpusRecord,SelectionConfig,analyse_records,select_records
ROOT=Path('/home/rehan/sct-gpu-supported-20261110')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def deny(sock,address):
 if sock.family in (socket.AF_INET,socket.AF_INET6):raise AssertionError('No network during GPU inference')
 return original_connect(sock,address)
original_connect=socket.socket.connect;socket.socket.connect=deny
assert torch.cuda.is_available();torch.cuda.set_per_process_memory_fraction(.1,0);torch.set_num_threads(2)
artifacts=json.loads(Path('/home/rehan/sct-improvements-r1-models-20261107/model-artifacts.json').read_text())
for info in artifacts.values():
 for name,sha in info['files'].items():assert digest(Path(info['snapshot'])/name)==sha
head_info,backbone_info=artifacts['quality_head'],artifacts['quality_backbone']
backbone=AutoModel.from_pretrained(backbone_info['snapshot'],local_files_only=True)
tokenizer=AutoTokenizer.from_pretrained(backbone_info['snapshot'],local_files_only=True)
head=torch.nn.Sequential(torch.nn.Linear(768,256),torch.nn.ReLU(),torch.nn.Dropout(.2),torch.nn.Linear(256,1))
state=torch.load(Path(head_info['snapshot'])/'model.pt',weights_only=True,map_location='cpu');head.load_state_dict({k.removeprefix('classifier.'):v for k,v in state.items()})
trained=QualityModel(backbone,head).eval()
cohorts = [['A river carries water toward the sea.'],
        ['short', 'A careful experiment records its input and measured output. ' * 8, 'qzx %% 123 junk'],
        ['Contact john.smith@example.org for this synthetic example.', 'Another short text.'],
        # Frozen numerical controls expose saturation; they do not establish model quality.
        ['A river carries water from higher ground toward a lake or the sea. Rain and melting snow feed its flow. '
         'Plants along the banks slow erosion, while roots hold soil in place. Floodplains absorb water during '
         'heavy rain and provide habitat for many species. Scientists measure flow, temperature, and sediment '
         'to understand how the river changes over time.',
         'The project team records each experiment so another engineer can reproduce the result. Each record '
         'includes the input, the method, and the measured output. Clear notes distinguish an observation from '
         'a prediction. Contact john.smith@example.org for this synthetic example; the address is not a real service.']]
reference=[]
for texts in cohorts:
 tokens=tokenizer(texts,return_tensors='pt',padding=True,truncation=True,max_length=512)
 with torch.inference_mode():reference.append(trained(tokens['input_ids'],tokens['attention_mask']).tolist())
assert min(v for row in reference for v in row)<.99
trained.to('cuda');gpu=[]
with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
 for texts,expected in zip(cohorts,reference):
  inputs={k:v.to('cuda') for k,v in tokenizer(texts,return_tensors='pt',padding=True,truncation=True,max_length=512).items()}
  with torch.inference_mode():result=trained(inputs['input_ids'],inputs['attention_mask'])
  assert result.is_cuda;actual=result.tolist();assert np.allclose(actual,expected,rtol=1e-4,atol=1e-5);gpu.append(actual)
  del inputs,result
 torch.cuda.synchronize()
trace=ROOT/'quality-torch-trace.json';prof.export_chrome_trace(str(trace));kernels=[e for e in json.loads(trace.read_text())['traceEvents'] if e.get('cat')=='kernel'];assert kernels
trained.cpu();del prof;gc.collect();torch._C._cuda_clearCublasWorkspaces();torch.cuda.empty_cache();print('CUDA allocation after cleanup',torch.cuda.memory_allocated(),flush=True);assert not any(p.is_cuda for p in trained.parameters());assert not any(b.is_cuda for b in trained.buffers());assert torch.cuda.memory_allocated()<1024**2
model_dir=Path('/home/rehan/sct-improvements-v090-20261109/r1-parity-control-py312-temp/test_trained_quality_export_ma0')
assert digest(model_dir/'model.onnx')=='0288133a7eb0209bfb501d1d5dfdcf7763acd727fec744b3443f40241fddeeaa'
base=ort.InferenceSession;sessions=[]
class Session(base):
 def __init__(self,*a,**kw):
  opt=ort.SessionOptions();opt.enable_profiling=True;opt.profile_file_prefix=str(ROOT/'quality-ort');opt.intra_op_num_threads=2;kw['sess_options']=opt;super().__init__(*a,**kw);sessions.append(self)
ort.InferenceSession=Session
scorer=ONNXQualityScorer(model_dir,revision=head_info['revision'],batch_size=3,providers=[('CUDAExecutionProvider',{'device_id':0,'gpu_mem_limit':2560*1024**2,'use_tf32':0}),'CPUExecutionProvider'])
assert scorer.session.get_providers()[0]=='CUDAExecutionProvider'
onnx_scores=[]
for texts,expected in zip(cohorts,reference):
 actual=scorer(texts);assert np.allclose(actual,expected,rtol=1e-4,atol=1e-5);onnx_scores.append(actual)
texts=[text for cohort in cohorts for text in cohort]
cleaner=TextCleaner(TextCleanerConfig.from_preset('training',pii_processing='unified',detector_specs=(DetectorSpec('builtin_regex'),),check_ner_process=False,check_detect_language=False))
selection=SelectionConfig(quality_min=.95)
with select_records(analyse_records([CorpusRecord(str(i),t) for i,t in enumerate(texts)],cleaner=cleaner,score_config=ScoreConfig(quality=True),selection=selection,scorer=scorer),selection=selection) as report:
 decisions=list(report.iter_decisions());assert len(decisions)==len(texts);assert len(report.kept_ids)==len(texts)
profile=Path(scorer.session.end_profiling());events=json.loads(profile.read_text());nodes=[e for e in events if e.get('args',{}).get('provider')=='CUDAExecutionProvider'];assert nodes
errors=[abs(a-b) for rows,refs in [(gpu,reference),(onnx_scores,reference)] for row,ref in zip(rows,refs) for a,b in zip(row,ref)]
(ROOT/'gpu-quality.json').write_text(json.dumps({'status':'passed','torch_gpu':gpu,'onnx_gpu':onnx_scores,'cpu_reference':reference,'max_absolute_error':max(errors),'tolerance':{'rtol':1e-4,'atol':1e-5},'minimum_reference':min(v for row in reference for v in row),'cuda_torch_kernels':len(kernels),'onnx_cuda_node_events':len(nodes),'quality_selection_records':len(decisions),'source_export_model_sha256':digest(model_dir/'model.onnx'),'torch_trace_sha256':digest(trace),'onnx_trace_sha256':digest(profile),'torch':torch.__version__,'onnxruntime_gpu':ort.__version__,'python':sys.version,'executable':sys.executable},indent=2));print('GPU quality parity and report-first dataset selection passed')
