from pathlib import Path
import os,json,subprocess,sys
root=Path('/home/rehan/sct-gpu-supported-20261110');name=sys.argv[1];assert name in ['gpu-quality.py','gpu-corpus.py']
env=dict(os.environ);env.update(json.loads((root/'gpu-environment.json').read_text()));env.update(PYTHONPATH=str(root),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_CACHE='/home/rehan/.cache/huggingface/hub',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
with (root/(name+'.log')).open('xb') as stream:r=subprocess.run(['taskset','-c','50-57',str(root/'.venv/bin/python'),str(root/name)],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
(root/(name+'.exit')).write_text(str(r.returncode));print(name,r.returncode);sys.exit(r.returncode)
