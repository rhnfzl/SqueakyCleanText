from pathlib import Path
import json,sys,os
import torch
import numpy as np
import onnx
import onnxruntime as ort
ROOT=Path('/home/rehan/sct-gpu-supported-20261110')
assert torch.cuda.is_available()
assert torch.cuda.device_count()==1
torch.cuda.set_per_process_memory_fraction(.1,0)
a=torch.ones((128,128),device='cuda');b=a@a;torch.cuda.synchronize();assert b[0,0].item()==128
from onnx import helper,TensorProto
model=helper.make_model(helper.make_graph([helper.make_node('MatMul',['a','b'],['out'])],'gpu-smoke',[helper.make_tensor_value_info(n,TensorProto.FLOAT,[128,128]) for n in ['a','b']],[helper.make_tensor_value_info('out',TensorProto.FLOAT,[128,128])]),opset_imports=[helper.make_opsetid('',17)]);model.ir_version=9
path=ROOT/'runtime-smoke.onnx';onnx.save(model,path)
opt=ort.SessionOptions();opt.enable_profiling=True;opt.profile_file_prefix=str(ROOT/'runtime-smoke');opt.intra_op_num_threads=2
session=ort.InferenceSession(str(path),sess_options=opt,providers=[('CUDAExecutionProvider',{'device_id':0,'gpu_mem_limit':512*1024**2}),'CPUExecutionProvider'])
assert session.get_providers()[0]=='CUDAExecutionProvider',session.get_providers()
r=session.run(None,{'a':np.ones((128,128),np.float32),'b':np.ones((128,128),np.float32)})[0];assert np.allclose(r,128)
profile=Path(session.end_profiling());events=json.loads(profile.read_text());cuda=[e for e in events if e.get('args',{}).get('provider')=='CUDAExecutionProvider'];assert cuda
(ROOT/'runtime-smoke.json').write_text(json.dumps({'python':sys.version,'executable':sys.executable,'torch':torch.__version__,'torch_file':torch.__file__,'cuda_build':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'onnxruntime':ort.__version__,'ort_file':ort.__file__,'providers':session.get_providers(),'cuda_node_events':len(cuda),'profile':str(profile),'torch_cuda_matmul':True},indent=2));print('Torch and ONNX executed CUDA matmul')
