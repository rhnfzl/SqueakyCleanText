from pathlib import Path
import json,hashlib,socket,sys
import torch,onnxruntime as ort
from sct import TextCleanerConfig,DetectorSpec
from sct.config import LANG_KEYS
from sct.corpus import curate_resumable
from sct.corpus.runner import _Lifecycle
ROOT=Path('/home/rehan/sct-gpu-supported-20261110');original_connect=socket.socket.connect

def deny(sock,address):
 if sock.family in (socket.AF_INET,socket.AF_INET6):raise AssertionError('No network during GPU corpus inference')
 return original_connect(sock,address)
socket.socket.connect=deny
assert torch.cuda.is_available();torch.cuda.set_per_process_memory_fraction(.1,0)
base=ort.InferenceSession;sessions=[];calls=0
class Session(base):
 def __init__(self,*a,**kw):
  options=kw.get('sess_options') or ort.SessionOptions();options.enable_profiling=True;options.profile_file_prefix=str(ROOT/'corpus-ort');kw['sess_options']=options;super().__init__(*a,**kw);assert self.get_providers()[0]=='CUDAExecutionProvider';sessions.append(self)
 def run(self,*a,**kw):
  global calls
  calls+=1;return super().run(*a,**kw)
ort.InferenceSession=Session
artifact=json.loads((ROOT/'gpu-artifacts.json').read_text())['onnx']
cfg=TextCleanerConfig.from_preset('training',pii_processing='unified',allow_network_detectors=True,detector_specs=(DetectorSpec('builtin_regex'),DetectorSpec('builtin_ner')),ner_backend='onnx',ner_device='cuda',language='ENGLISH',check_detect_language=False,ner_confidence_threshold=.3,ner_models={k:artifact['repo'] for k in LANG_KEYS},ner_model_revisions={k:artifact['revision'] for k in LANG_KEYS},onnx_intra_op_threads=2,onnx_inter_op_threads=1,onnx_cuda_provider_options={'gpu_mem_limit':1536*1024**2})
source=ROOT/'gpu-corpus-input-v4.jsonl';assert not source.exists()
source.write_text('\n'.join(json.dumps({'id':str(i),'text':text}) for i,text in enumerate(['John Smith works for Microsoft in London and carefully records scientific experiments. Email john.smith@example.org.','John Smith examines new computer hardware and describes detailed technology measurements. Email john.smith@example.org.'])))
source_before=source.read_bytes();output=ROOT/'gpu-corpus-output-v4';assert not output.exists()
# Owned synthetic controls only: expose the otherwise private stage failure.
from sct.corpus.datatrove import _StageRecords
original_stage = _StageRecords.run
def diagnose(self, *args, **kwargs):
 try:return original_stage(self, *args, **kwargs)
 except Exception:
  import traceback
  traceback.print_exc()
  raise
_StageRecords.run = diagnose
original=_Lifecycle.checkpoint

def interrupt(self,name,paths):
 original(self,name,paths)
 if name=='prepare':raise KeyboardInterrupt('owned GPU checkpoint control')
_Lifecycle.checkpoint=interrupt
try:
 try:curate_resumable(source,output,config=cfg,retention='caller_managed',workers=1)
 except KeyboardInterrupt:pass
 else:raise AssertionError('Expected controlled interruption')
finally:_Lifecycle.checkpoint=original
assert calls>0 and not (output/'manifest.json').exists();prepared_calls=calls
manifest=curate_resumable(source,output,config=cfg,retention='caller_managed',workers=1)
assert calls==prepared_calls,'Resume must reuse completed GPU preparation'
assert manifest.counts=={'input':2,'kept':2,'rejected':0}
kept=(output/'kept.jsonl').read_bytes();assert b'John Smith' not in kept and b'john.smith@example.org' not in kept
before={n:(output/n).read_bytes() for n in ['manifest.json','kept.jsonl']}
assert curate_resumable(source,output,config=cfg,retention='caller_managed',workers=1).counts==manifest.counts
assert calls==prepared_calls and source.read_bytes()==source_before
assert all((output/n).read_bytes()==value for n,value in before.items())
profiles=[];cuda=0
for session in sessions:
 path=Path(session.end_profiling());nodes=[e for e in json.loads(path.read_text()) if e.get('args',{}).get('provider')=='CUDAExecutionProvider'];cuda+=len(nodes);profiles.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'cuda_nodes':len(nodes)})
assert cuda>0
(ROOT/'gpu-corpus.json').write_text(json.dumps({'status':'passed','counts':dict(manifest.counts),'gpu_session_runs':prepared_calls,'cuda_node_events':cuda,'resume_reused_gpu_stage':True,'completed_rerun_reused_gpu_stage':True,'caller_input_unchanged':True,'published_outputs_unchanged':True,'person_and_contact_protected':True,'profiles':profiles,'python':sys.version,'executable':sys.executable,'onnxruntime_gpu':ort.__version__},indent=2));print('GPU corpus processing, interruption and resume passed')
