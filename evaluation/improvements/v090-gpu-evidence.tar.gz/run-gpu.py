from pathlib import Path
import subprocess,os,json,sys
ROOT=Path('/home/rehan/sct-gpu-supported-20261110')
site=ROOT/'.venv/lib/python3.12/site-packages'
libs=[str(p) for p in sorted((site/'nvidia').glob('*/lib'))]+[str(site/'torch/lib')]
assert any((Path(p)/'libcudnn_adv.so.9').exists() for p in libs)
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-5a285e5a-6883-d8af-9928-81d2ab04a33e',LD_LIBRARY_PATH=':'.join(libs),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONPATH=str(ROOT),TLDEXTRACT_CACHE='/home/rehan/sct-improvements-v090-20261109/r1-public-suffix-cache',HF_HUB_CACHE='/home/rehan/.cache/huggingface/hub')
(ROOT/'gpu-environment.json').write_text(json.dumps({k:env[k] for k in ['CUDA_VISIBLE_DEVICES','LD_LIBRARY_PATH','OMP_NUM_THREADS','HF_HUB_OFFLINE']},indent=2))
if sys.argv[1]=='smoke':
 with (ROOT/'runtime-smoke-corrected.log').open('wb') as stream:r=subprocess.run([str(ROOT/'.venv/bin/python'),str(ROOT/'runtime-smoke.py')],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 print('runtime-smoke',r.returncode);sys.exit(r.returncode)
import importlib.util
old=Path('/home/rehan/sct-improvements-v090-20261109/r1-native-artifacts.json');art=json.loads(old.read_text())
probe="import en_core_web_lg;from pathlib import Path;print(Path(en_core_web_lg.__file__).parent)"
art['spacy']['snapshot']=subprocess.check_output([str(ROOT/'.venv/bin/python'),'-c',probe],text=True).strip()
(ROOT/'gpu-artifacts.json').write_text(json.dumps(art,indent=2))
results=ROOT/'gpu-results';results.mkdir(exist_ok=True)
for provider in ['onnx','torch','gliner','ensemble_onnx','ensemble_torch','presidio_gliner','gliner2','classify']:
 if provider=='gliner2':env['HF_HUB_CACHE']='/home/rehan/sct-improvements-v090-20261109/r1-native-model-cache'
 else:env['HF_HUB_CACHE']='/home/rehan/.cache/huggingface/hub'
 output=results/(provider+'.json');assert not output.exists()
 command=['taskset','-c','50-57',str(ROOT/'.venv/bin/python'),str(ROOT/'scripts/qualify_gpu.py'),'--provider',provider,'--artifacts',str(ROOT/'gpu-artifacts.json'),'--output',str(output)]
 with (results/(provider+'.log')).open('wb') as stream:r=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
 print(provider,r.returncode,flush=True)
 assert r.returncode==0,f'See {results}/{provider}.log'
