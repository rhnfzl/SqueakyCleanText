from pathlib import Path
import subprocess,tarfile,hashlib,json,re,os
ROOT=Path('/home/rehan/sct-gpu-supported-20261110')
assert hashlib.sha256((ROOT/'source.tar').read_bytes()).hexdigest()=='b4ca3b91ddb32ec32ab71531c7609a9926636ce489feb6ebd9aae6990aa6e347'
with tarfile.open(ROOT/'source.tar') as t:t.extractall(ROOT,filter='data')
os.chdir(ROOT)
old='/home/rehan/sct-improvements-v090-20261109/.venv-models312/bin/python'
freeze=subprocess.check_output(['uv','pip','freeze','--python',old],text=True)
excluded=[];lines=[]
for line in freeze.splitlines():
 name=re.split(r'[ =@]',line.lower())[0]
 if not line or line.startswith('#'):continue
 if line.startswith('-e') or name.startswith(('torch','nvidia','triton','onnxruntime','cuda-','squeakycleantext')):excluded.append(name)
 else:lines.append(line)
(ROOT/'requirements-base.txt').write_text('\n'.join(lines)+'\n')
commands=[['uv','venv','--python','3.12',str(ROOT/'.venv')],
 ['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'--no-deps','-r',str(ROOT/'requirements-base.txt')],
 ['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'torch==2.14.0+cu126','--index-url','https://download.pytorch.org/whl/cu126','--extra-index-url','https://pypi.org/simple','--index-strategy','unsafe-best-match'],
 ['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'onnxruntime-gpu==1.24.2','datatrove==0.10.1','datasketch==2.0.0','orjson'],
 ['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'--no-deps','-e',str(ROOT)]]
for i,command in enumerate(commands):
 log=ROOT/f'setup-{i}.log'
 with log.open('wb') as stream:r=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 (ROOT/f'setup-{i}.exit').write_text(str(r.returncode))
 print(i,r.returncode,flush=True)
 assert r.returncode==0,f'See {log}'
(ROOT/'setup.json').write_text(json.dumps({'commands':commands,'excluded_cpu_profile_packages':excluded,'base_requirements':len(lines)},indent=2))
