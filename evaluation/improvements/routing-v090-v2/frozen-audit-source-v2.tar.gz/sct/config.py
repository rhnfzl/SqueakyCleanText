"""
Configuration for the SqueakyCleanText pipeline.

Pass an immutable config to each cleaner:
    from sct.config import TextCleanerConfig
    cfg = TextCleanerConfig(check_ner_process=False)
    cleaner = TextCleaner(cfg)
"""

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date
from types import MappingProxyType
from typing import Any, Literal, get_args
from collections.abc import Mapping

from sct.detectors import DetectorSpec
from sct.utils.resources import DEFAULT_LANGUAGES, resolve_language
from sct.utils.markers import LABEL_PATTERN


LANG_KEYS = ('ENGLISH', 'DUTCH', 'GERMAN', 'SPANISH', 'MULTILINGUAL')
REQUIRED_NER_KEYS = frozenset({'ENGLISH', 'MULTILINGUAL'})

NerBackend = Literal['onnx', 'torch', 'gliner', 'ensemble_onnx', 'ensemble_torch', 'presidio_gliner']
NerMode = Literal['standard', 'pii']
ReplacementMode = Literal['placeholder', 'synthetic', 'reversible']
JsonKeyCleaning = Literal['pii', 'pii_ner', 'full', 'off']
NerEnsembleVote = Literal['max', 'mean']
ReplaceNumbersMode = Literal['identifiers', 'all']
OnPatternTimeout = Literal['raise', 'warn']

VALID_NER_BACKENDS = frozenset(get_args(NerBackend))
GLINER_BACKENDS = frozenset({'gliner', 'ensemble_onnx', 'ensemble_torch', 'presidio_gliner'})
# Backends that run SCT's own GLiNER adapter; presidio_gliner loads GLiNER through Presidio.
GLINER_ADAPTER_BACKENDS = GLINER_BACKENDS - {'presidio_gliner'}
ONNX_BACKENDS = frozenset({'onnx', 'ensemble_onnx'})
TORCH_BACKENDS = frozenset({'torch', 'ensemble_torch'})
TOKEN_MODEL_BACKENDS = ONNX_BACKENDS | TORCH_BACKENDS

_ONNX_CHECKPOINTS = (
    (('ENGLISH',), 'rhnfzl/xlm-roberta-large-conll03-english-onnx', '2c10955af9538d6ff8a68316c5dbfcd0b968761e'),
    (('DUTCH',), 'rhnfzl/xlm-roberta-large-conll02-dutch-onnx', '381e34ba4c222bc221e9fd02832f52a179ed840d'),
    (('GERMAN',), 'rhnfzl/xlm-roberta-large-conll03-german-onnx', 'fe4aecfa6dc376244ef37da37e6df3b1b0911d71'),
    (('SPANISH',), 'rhnfzl/xlm-roberta-large-conll02-spanish-onnx', 'ef52a7f08172203c763d51fe36660d36985bb388'),
    (('FRENCH', 'PORTUGUESE', 'ITALIAN', 'MULTILINGUAL'),
     'rhnfzl/wikineural-multilingual-ner-onnx', '74191432b21c956b5b04b4778c0e92e569b1f80d'),
)
_TORCH_CHECKPOINTS = (
    (('ENGLISH',), 'FacebookAI/xlm-roberta-large-finetuned-conll03-english', '18f95e9924f3f452df09cc90945073906ef18f1e'),
    (('DUTCH',), 'FacebookAI/xlm-roberta-large-finetuned-conll02-dutch', '630d5d48d08071704d9a2719b045082019b6ac12'),
    (('GERMAN',), 'FacebookAI/xlm-roberta-large-finetuned-conll03-german', '1fbcc7a00a69ce5ab754623154a8e9cc6ba868e2'),
    (('SPANISH',), 'FacebookAI/xlm-roberta-large-finetuned-conll02-spanish', 'a7c5f08c766adcbd6c22f343145fa65d38b3c1d5'),
    (('FRENCH', 'PORTUGUESE', 'ITALIAN', 'MULTILINGUAL'),
     'Babelscape/wikineural-multilingual-ner', 'bed6ee7a45d2827b6c90a4fd7983f0241ae0a5c1'),
)
DEFAULT_NER_MODELS = {key: model for keys, model, _ in _ONNX_CHECKPOINTS for key in keys}
DEFAULT_NER_REVISIONS = {key: revision for keys, _, revision in _ONNX_CHECKPOINTS for key in keys}
DEFAULT_TORCH_NER_MODELS = {key: model for keys, model, _ in _TORCH_CHECKPOINTS for key in keys}
DEFAULT_TORCH_NER_REVISIONS = {key: revision for keys, _, revision in _TORCH_CHECKPOINTS for key in keys}
_DEFAULT_CONFIG_NER_MODELS = {key: DEFAULT_NER_MODELS[key] for key in LANG_KEYS}

# NER ensemble: ordered model keys to run per input language.
# Keys must exist in the resolved ner_models dict.
# EN/NL/DE/ES get a 3-model ensemble (lang-specific + English CoNLL + Multilingual).
# All other languages (FR, PT, IT, etc.) fall back to NER_ENSEMBLE_DEFAULT_KEYS.
DEFAULT_NER_ENSEMBLE: dict[str, tuple] = {
    'ENGLISH': ('ENGLISH', 'MULTILINGUAL'),
    'DUTCH':   ('DUTCH',   'ENGLISH', 'MULTILINGUAL'),
    'GERMAN':  ('GERMAN',  'ENGLISH', 'MULTILINGUAL'),
    'SPANISH': ('SPANISH', 'ENGLISH', 'MULTILINGUAL'),
}
# Fallback for any language not in DEFAULT_NER_ENSEMBLE (FR, PT, IT, etc.)
NER_ENSEMBLE_DEFAULT_KEYS: tuple = ('MULTILINGUAL', 'ENGLISH')

# PII label categories (compatible with knowledgator/gliner-pii-base-v1.0)
PII_LABELS: tuple[str, ...] = (
    # Personal
    'name', 'first_name', 'last_name', 'date_of_birth', 'age',
    'gender', 'marital_status', 'nationality',
    # Contact
    'email', 'phone_number', 'ip_address', 'url',
    'street_address', 'city', 'state', 'country', 'zip_code',
    # Financial (PCI)
    'credit_card_number', 'cvv', 'expiration_date',
    'social_security_number', 'bank_account_number', 'routing_number', 'tax_id',
    # Healthcare (PHI)
    'medical_condition', 'drug_name', 'dosage', 'blood_type',
    'medical_code', 'healthcare_number',
    # Identity
    'passport_number', 'driver_license_number', 'username', 'password',
    'vehicle_identification_number',
    # Employment
    'company_name', 'job_title', 'employee_id', 'salary',
    # Digital
    'mac_address', 'imei', 'device_id', 'api_key', 'access_token',
    # Relationship
    'spouse_name', 'child_name', 'emergency_contact',
    # Geographic
    'latitude', 'longitude', 'gps_coordinates',
    # Temporal
    'date', 'time', 'timestamp',
    # Misc
    'account_number', 'license_plate', 'serial_number',
    'insurance_policy_number', 'beneficiary',
)

PII_LABEL_MAP: dict[str, str] = {
    'name': 'PER', 'first_name': 'PER', 'last_name': 'PER',
    'spouse_name': 'PER', 'child_name': 'PER', 'emergency_contact': 'PER',
    'company_name': 'ORG', 'court_name': 'ORG', 'school_name': 'ORG',
    'city': 'LOC', 'state': 'LOC', 'country': 'LOC',
    # One name per type on every surface: the regex steps emit <PHONE> / <IP> too.
    'phone_number': 'PHONE', 'ip_address': 'IP',
}

# legacy_type_names -> the label map PII mode derives (identity marks it as derived).
_PII_MAPS = {legacy: MappingProxyType({k: v for k, v in PII_LABEL_MAP.items()
                                       if not (legacy and v in ('PHONE', 'IP'))})
             for legacy in (False, True)}

PII_DEFAULT_MODEL = 'knowledgator/gliner-pii-base-v1.0'
PII_DEFAULT_REVISION = '61726e0ad791dcab3e29339bbec3ad42ded65641'
PII_DEFAULT_THRESHOLD = 0.3  # Recall > precision for PII

VALID_NER_MODES = frozenset(get_args(NerMode))
VALID_REPLACEMENT_MODES = frozenset(get_args(ReplacementMode))
VALID_JSON_KEY_CLEANING = frozenset(get_args(JsonKeyCleaning))

# Optional ModernBERT NER models (available when exported via export_onnx_models.py)
MODERNBERT_NER_MODELS: dict[str, str] = {
    'ENGLISH': 'rhnfzl/modernbert-base-ner-conll03-english-onnx',
    # Multilingual: not yet available — WikiNEuRaL remains the best option
    'MULTILINGUAL': 'rhnfzl/wikineural-multilingual-ner-onnx',
}

# GLiClass document-level classification defaults
GLICLASS_DEFAULT_MODEL = 'knowledgator/gliclass-edge-v3.0'      # 32.7M params, 131MB
GLICLASS_DEFAULT_REVISION = 'df03993a2ed98e5e4a0d2dd7efbbd105abe874cf'

@dataclass(frozen=True)
class TextCleanerConfig:
    """Thread-safe, immutable configuration for the text cleaning pipeline.

    Each TextCleaner instance stores its own config copy. Use
    ``dataclasses.replace()`` to create modified copies::

        import dataclasses
        new_cfg = dataclasses.replace(cfg, check_ner_process=False)
    """

    # Pipeline step toggles
    check_detect_language: bool = True
    check_fix_bad_unicode: bool = True
    check_to_ascii_unicode: bool = False  # True = unidecode transliteration (0.7: 日本語 -> Ri Ben Yu)
    check_replace_html: bool = True
    check_replace_urls: bool = True
    check_replace_emails: bool = True
    check_replace_years: bool = True
    check_replace_dates: bool = True
    check_fuzzy_replace_dates: bool = False
    check_replace_phone_numbers: bool = True
    check_replace_numbers: bool = True
    check_replace_currency_symbols: bool = True
    check_ner_process: bool = True
    check_remove_isolated_letters: bool = True
    check_remove_isolated_special_symbols: bool = True
    check_remove_bracket_content: bool = True
    check_remove_brace_content: bool = True
    check_normalize_whitespace: bool = True
    check_statistical_model_processing: bool = True
    check_casefold: bool = True
    check_smart_casefold: bool = False
    check_remove_stopwords: bool = True
    check_remove_punctuation: bool = True
    check_remove_stext_custom_stop_words: bool = True
    check_remove_emoji: bool = False

    # Fuzzy matching settings (requires rapidfuzz optional dependency)
    # Empirically calibrated: 85 catches 18/19 common misspellings (e.g.
    # "Feburary", "Septmber", "enro") while avoiding false positives from
    # common words.  Lower to 80 for maximum recall (catches "Agusto"→agosto
    # at 83.3 but risks rare FP like "jungle"→june at 80).  Raise to 87+ for
    # zero false-positive risk at the cost of missing some edge-case typos.
    fuzzy_date_score_cutoff: int = 85

    # Replacement tokens
    replace_with_url: str = "<URL>"
    replace_with_html: str = "<HTML>"
    replace_with_email: str = "<EMAIL>"
    replace_with_years: str = "<YEAR>"
    replace_with_dates: str = "<DATE>"
    replace_with_phone_numbers: str = "<PHONE>"
    replace_with_numbers: str = "<NUMBER>"
    replace_with_currency_symbols: str | None = None

    # NER settings
    positional_tags: tuple[str, ...] = ('PER', 'LOC', 'ORG', 'MISC')
    ner_confidence_threshold: float | None = None  # None = effective_ner_confidence_threshold
    ner_batch_size: int = 8
    language: str | tuple[str, ...] | None = None

    # NER backend selection
    ner_backend: NerBackend = 'onnx'

    # NER mode: 'standard' uses configured models, 'pii' auto-configures GLiNER for PII detection
    ner_mode: NerMode = 'standard'
    # Replacement mode: 'placeholder' uses <TAG> tokens, 'synthetic' uses Faker-generated values
    replacement_mode: ReplacementMode = 'placeholder'

    # Preferred: language-keyed dict of HuggingFace ONNX model repo IDs.
    # Models must have model.onnx, config.json, tokenizer.json on Hub.
    # ENGLISH and MULTILINGUAL are always required (loaded eagerly).
    # Missing keys are filled from DEFAULT_NER_MODELS.
    ner_models: Mapping[str, str] | None = None
    ner_model_revisions: Mapping[str, str] | None = None

    # Ensemble routing: maps each input language to an ordered tuple of model keys
    # to run. Keys must exist in the resolved ner_models dict.
    # If None, DEFAULT_NER_ENSEMBLE is used (with NER_ENSEMBLE_DEFAULT_KEYS fallback).
    ner_ensemble: Mapping[str, tuple[str, ...]] | None = None

    # Fallback keys for any language not listed in ner_ensemble (e.g. FR, PT, IT).
    # If None, NER_ENSEMBLE_DEFAULT_KEYS is used. Pass an empty tuple to skip
    # ensemble inference for unmapped languages.
    ner_ensemble_default_keys: tuple[str, ...] | None = None

    # Torch backend models (only used when ner_backend is 'torch' or 'ensemble_torch')
    torch_ner_models: Mapping[str, str] | None = None
    torch_ner_model_revisions: Mapping[str, str] | None = None

    # GLiNER settings (only used when ner_backend contains 'gliner' or 'ensemble')
    gliner_model: str | None = None
    gliner_revision: str | None = None
    gliner_variant: str = 'gliner'  # 'gliner' or 'gliner2'
    gliner_labels: tuple[str, ...] = ('person', 'organization', 'location')
    gliner_label_map: Mapping[str, str] | None = None
    gliner_threshold: float | None = None  # None = effective_gliner_threshold

    # Entity description labels (ZERONER-style): maps labels to natural-language descriptions.
    # When provided, descriptions are sent to GLiNER for inference, results mapped back to labels.
    # Example: {'person': "a person's full legal name", 'location': "a geographical place name"}
    gliner_label_descriptions: Mapping[str, str] | None = None

    # Load GLiNER model in ONNX mode (uses pre-built ONNX weights from HuggingFace Hub).
    # Only works with uni-encoder models. Auto-set when ner_mode='pii' + ner_backend='onnx'.
    gliner_onnx: bool = False

    # GLiClass document-level pre-classification (zero-shot)
    check_classify_document: bool = False
    gliclass_model: str | None = None
    gliclass_revision: str | None = None
    gliclass_labels: tuple[str, ...] = ()
    gliclass_threshold: float = 0.5
    gliclass_classification_type: str = 'single-label'
    gliclass_onnx: bool = False

    # Plugin: user-provided pipeline steps, each callable (text: str) -> str.
    # Appended to the pre-NER pipeline in _init_pipeline(), so they run before NER.
    custom_pipeline_steps: tuple = ()

    # Language extensibility — extend Lingua detection, stopwords, dates, NER
    extra_languages: tuple[str, ...] = ()
    custom_stopwords: Mapping[str, frozenset] | None = None
    custom_month_names: Mapping[str, tuple[str, ...]] | None = None

    # Computed at __post_init__ — union of all language sources
    supported_languages: frozenset = frozenset()

    # Added in 0.7.1; kept last so existing positional arguments keep their meaning.
    check_replace_ips: bool = True
    replace_ips_public_only: bool = False  # True keeps private/loopback/reserved IPs
    replace_with_ips: str = "<IP>"
    replace_numbers_in_words: bool = False  # True also replaces digits glued to Latin/Greek/Cyrillic letters (GPT4)

    # Added in 0.8.0; kept last so existing positional arguments keep their meaning.
    onnx_intra_op_threads: int | None = None  # None = ONNX Runtime default (all cores)
    onnx_inter_op_threads: int | None = None  # None = ONNX Runtime default
    ner_chunk_overlap: int = 0  # tokens of neighbouring text each NER window adds per side; 0 = 0.7.1 chunks
    detect_all_languages: bool = True  # False = 0.7 detector over supported_languages only
    language_confidence_warning: float = 0.0  # below this confidence, warn language_low_confidence; 0.5 = early 0.8.0
    check_decode_unicode_escapes: bool = True  # False keeps literal \n, \u00e9 escapes (code, JSON)
    ner_device: str | None = None  # None = auto (CUDA when available), 'cpu', 'cuda', 'mps'
    cuda_device_id: int = 0  # GPU index for ONNX, torch and GLiNER when on CUDA
    onnx_cuda_provider_options: Mapping[str, Any] | None = None  # extra CUDAExecutionProvider options
    # process_json keys: 'pii' = regex PII steps only (NER tags lone words like 'message' out of context),
    # 'pii_ner' = PII steps plus NER, 'full' = whole config (0.7), 'off' = raw
    json_key_cleaning: JsonKeyCleaning = 'pii'
    synthetic_seed: int = 42  # base seed for replacement_mode='synthetic'
    # True: fakes seeded per document from synthetic_seed + its text (differ across documents,
    # same document -> same fakes); False = 0.7 single Faker stream per thread
    synthetic_per_document: bool = True
    # Warn language_low_confidence when the top language leads the runner-up by less than this
    # (ambiguous detection); 0 turns it off. Absolute confidence is low for many correct texts.
    language_margin_warning: float = 0.15
    # Part of check_fix_bad_unicode. False keeps full-width CJK punctuation (，！：) and half-width
    # katakana, converting only full-width ASCII letters/digits; True = ftfy's full width fix (0.7)
    fix_character_width: bool = False
    # True: phone and IP types use their pre-0.8.0 names PHONE_NUMBER / IP_ADDRESS in reversible
    # placeholders, metadata, signals and PII-mode NER tags; False = PHONE / IP everywhere
    legacy_type_names: bool = False
    # WordPiece NER: widen an entity to its whole word when the added text is at most this many
    # times the tagged span ("John Do" + "##e"); None = always (whole unspaced Thai/kana clauses
    # too), 0 = never (0.7)
    ner_subword_widen: float | None = 1.0
    # Part of check_fix_bad_unicode. True folds math-alphanumeric (𝐞𝐱), circled (ⓙ) and full-width
    # URL punctuation (：／？) inside ASCII runs and drops invisible Cf characters (ZWSP, soft hyphen)
    # inside them, so styled emails/URLs/phones are replaced without
    # check_to_ascii_unicode; False = earlier 0.8.0 (full-width letters/digits and ＠．－＿＋ only)
    fold_styled_characters: bool = True
    # WordPiece NER widening stops where the Unicode script of the letters changes, so a Latin
    # name glued to kana or Thai ("David Millerは") keeps its own span; False = widen across scripts
    ner_subword_widen_same_script: bool = True
    # Faker locale for replacement_mode='synthetic': None = follow the detected document language
    # (Dutch text gets Dutch names, en_US when Faker has no locale for it); a string forces that
    # locale ('en_US' = 0.7)
    synthetic_locale: str | None = None
    # synthetic/reversible: NER reads the same text as placeholder mode (<EMAIL>, <PHONE>...) and
    # the fakes / indexed placeholders go in after NER, so every mode finds the same entities;
    # False = 0.7 order (NER reads the fakes / <EMAIL_0>)
    ner_sees_tags: bool = True
    # synthetic_locale=None: Faker locale for documents whose detection gets the
    # language_low_confidence warning; None = follow the detected language anyway (earlier 0.8.0)
    synthetic_low_confidence_locale: str | None = 'en_US'
    # synthetic: drop a fake's final '.' when a '.' follows the entity ('B.Eng..' -> 'B.Eng.');
    # False = keep both (earlier 0.8.0)
    synthetic_collapse_period: bool = True
    # synthetic: ISO date that date fakes (DATE, DATE_OF_BIRTH) end on, so a document gets the
    # same dates on any day; None = today, from the clock (earlier 0.8.0)
    synthetic_reference_date: str | None = '2026-01-01'
    # NER ensemble vote per span: 'max' keeps a span when its best model score passes
    # ner_confidence_threshold, so a weak second model never hides a strong hit; 'mean' averages
    # the model scores (0.8.0)
    ner_ensemble_vote: NerEnsembleVote = 'max'
    # mask every other case-sensitive whole-word copy of a masked person/org/location value in the same
    # document (the value comes from the model's own span); False = 0.8.0 output
    ner_propagate_masked: bool = True
    # score a span needs before its value is propagated (0..1); None = the effective NER cut.
    # Raising it spreads fewer wrong tags at the cost of more visible repeats
    ner_propagate_min_score: float | None = None
    # IBANs (mod-97 checksum) and payment cards (Luhn checksum) become one <IBAN> / <CARD> each,
    # before the phone step; False = 0.8.0 (the phone/number steps take pieces of them)
    check_replace_iban_cards: bool = True
    replace_with_iban: str = "<IBAN>"
    replace_with_cards: str = "<CARD>"
    # Identifier tokens: 6+ uppercase letters and digits with 2+ digits and a letter (RBCON68T08).
    # Off by default: the shape also takes product and reference codes (COVID19)
    check_replace_identifiers: bool = False
    replace_with_identifiers: str = "<ID>"
    # Bracket/brace removal only takes innermost spans of at most this many characters and
    # whitespace-separated words, so prose clauses stay; 0 = no limit (both 0 = 0.8.0 matching)
    bracket_content_max_chars: int = 32
    bracket_content_max_words: int = 3
    # A {...} that parses as a JSON object (json.raw_decode, nested ones included) is never removed
    keep_json_braces: bool = True
    # A month name, "/" and a 2- or 4-digit year is one <DATE> (October/55, Oct/2019)
    date_month_name_slash_year: bool = True
    # ISO codes of the built-in month data dates use (en nl de es fr pt it th); None = all
    date_builtin_month_languages: tuple[str, ...] | None = None
    # HTML rule reads only tag shapes (<b>, </a>, <br/>, <!-- -->); False = 0.8.0 "<.*?>" (eats "<a@b.com>")
    html_tag_strict: bool = True
    # join two location spans whose gap has <= N chars (placeholders not counted), no line break
    # and no sentence end, so an address is one <LOCATION>; 0 = off (0.8.0 output)
    ner_merge_location_gap: int = 0
    # NER span edges cut inside a word (letters and marks, not wide CJK) move out to the word
    # edges on every backend ("Salut" -> "Salute"), within the ner_subword_widen cap and
    # same-script rule; False = 0.8.0 spans
    ner_snap_word_edges: bool = True
    # . , ; : ! ? ' end a URL path or query unless more URL text follows ("https://x.com/a. Next");
    # False = 0.8.0, where the URL takes the sentence's full stop or comma
    url_trailing_punct_outside: bool = True
    # check_replace_numbers: 'identifiers' masks only whole digit runs of an identifier shape (not glued to
    # letters, digits or joined parts such as INV-2023-107683, which stays untouched; not an amount, decimal,
    # percent, time or range); 'all' = 0.8.1, every number. On the DEV split of the external benchmark the
    # 'all' rule caused 62-68% of SCT's false masks.
    replace_numbers_mode: ReplaceNumbersMode = 'identifiers'
    # Fewest digits an identifier-shaped number needs. 4: on DEV (9 datasets, 4,298 docs, years/dates off,
    # phone_reject_embedded on) 4 digits gave F2 0.881 / recall 0.893 / precision 0.856, the best F2 of 4-7;
    # 7 digits gave 0.869 / precision 0.865. Shorter runs (ages, counts, list numbers) are left as they are.
    replace_numbers_min_digits: int = 4
    # Drop a digit-only phone match glued to a Latin/Greek/Cyrillic letter or "_", directly or across a joiner
    # (ID9876543210, ref-0612345678), or that is a yyyymmdd date or yyyymmddhhmm[ss] timestamp (20231105123456); formatted and
    # international phones are not touched. On DEV:
    # precision +0.02, recall -0.01. False = 0.8.1
    phone_reject_embedded: bool = True
    # User term lists (SCT ships none; the user decides the words). Empty by default.
    # {LABEL: (term, ...)}: always mask these terms as <LABEL>, as whole words (no letter, mark or digit of a
    # spaced script glued to them; an edge in CJK/Thai is a word edge). Runs before the built-in regex steps.
    custom_deny_terms: Mapping[str, tuple[str, ...]] | None = None
    # Never mask these terms: a regex or NER detection equal to or inside an occurrence is kept as text.
    # Applied last, so it also wins over custom_deny_terms and custom_patterns.
    custom_allow_terms: tuple[str, ...] = ()
    # {LABEL: regex}: mask every match as <LABEL> (the third-party ``regex`` module, compiled once). Runs
    # with custom_deny_terms, before the built-in steps. A pattern that can match "" is rejected; a pattern
    # with nested repeats can backtrack for a long time (ReDoS), so only pass patterns you trust.
    custom_patterns: Mapping[str, str] | None = None
    # Whether custom_deny_terms and custom_allow_terms match case-sensitively. False: "acme" matches "ACME".
    custom_terms_case_sensitive: bool = False
    # replace_numbers_mode='identifiers' only: whole-token ID shapes the plain digit-run rule rejects (format
    # rules, not replace_numbers_min_digits). Each was measured on the DEV split against 0.8.1's recall.
    # 1-3 uppercase letters, 6+ digits, 0-2 uppercase letters (AB1234567, X12345678Z); not USD1000000
    numbers_letter_prefix_ids: bool = True
    # Two digit groups joined by "/" or a hyphen (first 4+ digits, 7+ in all, optional check letter:
    # 123456/7890, 12345-678901) or by "." (4+ digits each side: 12345.67890); not 2023-2024 or 1000-3000
    numbers_two_part_ids: bool = True
    # "DDD DD", a 5-digit postal code written with a space (123 45), and a run of 3+ digit groups joined by
    # spaces and/or hyphens with 7+ digits (123 45 6789, 123 45-6789); not dates or 1 234 567
    numbers_spaced_pair_ids: bool = True
    # Seconds each custom_patterns regex may spend on one document (the regex module's timeout), so a pattern
    # that backtracks badly (ReDoS) cannot hang processing. None: no limit.
    custom_patterns_timeout: float | None = 2.0
    # On a timeout: 'raise' a CustomPatternTimeout (names the label, never the text), or 'warn': log it, add
    # 'custom_pattern_timeout' to metadata['warnings'] and process that document without the pattern.
    custom_patterns_on_timeout: OnPatternTimeout = 'raise'
    # replace_numbers_mode='identifiers' only: a number right before or after an uppercase ISO 4217 code, with at
    # most one space ("1250 EUR", "EUR 1250", "USD 1,250"), is an amount and stays. False: masked like any ID
    numbers_keep_currency_code_amounts: bool = True

    # Appended to preserve existing positional configuration arguments.
    detector_specs: tuple[DetectorSpec, ...] = ()
    allow_network_detectors: bool = False
    # Unified mode collects all selected findings before applying one policy and renderer.
    pii_processing: Literal["legacy", "unified"] = "legacy"
    source_mapping: Literal["best_effort", "require_source"] = "best_effort"
    language_policy: Literal['legacy', 'abstain'] = 'legacy'
    language_min_confidence: float | None = None
    language_min_margin: float | None = None
    unknown_language_action: Literal['multilingual', 'error', 'skip_ner'] = 'multilingual'

    routing_policy: Literal['always_run', 'calibrated_cascade'] = 'always_run'
    routing_fast_specs: tuple[DetectorSpec, ...] = ()
    routing_full_specs: tuple[DetectorSpec, ...] = ()
    routing_entity_types: tuple[str, ...] = ()
    routing_calibration: Mapping[str, Any] | None = None

    def __post_init__(self):
        if self.language_policy not in ('legacy', 'abstain'):
            raise ValueError('language_policy must be legacy or abstain')
        if self.unknown_language_action not in ('multilingual', 'error', 'skip_ner'):
            raise ValueError('unknown_language_action must be multilingual, error or skip_ner')
        for name in ('language_min_confidence', 'language_min_margin'):
            value = getattr(self, name)
            if value is not None and (type(value) not in (int, float) or not 0.0 <= value <= 1.0):
                raise ValueError(f'{name} must be None or a finite number in [0, 1]')
        if self.pii_processing not in ("legacy", "unified"):
            raise ValueError("pii_processing must be legacy or unified")
        if self.source_mapping not in ("best_effort", "require_source"):
            raise ValueError("source_mapping must be best_effort or require_source")
        if type(self.allow_network_detectors) is not bool:
            raise ValueError("allow_network_detectors must be a boolean")
        specs = tuple(DetectorSpec(**item) if isinstance(item, Mapping) else item for item in self.detector_specs)
        if any(not isinstance(item, DetectorSpec) for item in specs):
            raise ValueError("detector_specs must contain DetectorSpec values")
        object.__setattr__(self, "detector_specs", specs)
        if self.synthetic_reference_date is not None:
            date.fromisoformat(self.synthetic_reference_date)  # ValueError on a bad date
        _apply_gliclass_defaults(self)
        _freeze_sequences(self)
        _validate_modes(self)
        _apply_pii_defaults(self)
        _validate_ner_settings(self)
        _validate_gliner(self)
        _reconcile_torch_models(self)
        _reconcile_ner_models(self)
        _resolve_languages(self)
        _validate_user_terms(self)
        _compute_supported_languages(self)
        from sct.routing import validate_routing_config
        validate_routing_config(self)

    @property
    def effective_gliner_threshold(self) -> float:
        """GLiNER score cut: explicit value, else 0.3 in PII mode, else 0.4."""
        if self.gliner_threshold is not None:
            return self.gliner_threshold
        return PII_DEFAULT_THRESHOLD if self.ner_mode == 'pii' else 0.4

    @property
    def effective_ner_confidence_threshold(self) -> float:
        """Final NER filter: explicit value, else the GLiNER cut in PII mode, else 0.85."""
        if self.ner_confidence_threshold is not None:
            return self.ner_confidence_threshold
        # PII mode: the final ensemble filter must not drop what GLiNER kept.
        return self.effective_gliner_threshold if self.ner_mode == 'pii' else 0.85

    @classmethod
    def from_preset(cls, name: str = "training", **overrides: Any) -> "TextCleanerConfig":
        """Build a config from a named preset (see ``sct.presets.PRESETS``)."""
        # deferred: sct.presets imports this module at load
        from sct.presets import preset_config
        return preset_config(name, **overrides)

    def _plain_state(self) -> dict[str, Any]:
        """The fields as plain values: mapping proxies as dicts, a PII-derived gliner_label_map as None."""
        state = {k: dict(v) if isinstance(v, MappingProxyType) else v for k, v in self.__dict__.items()}
        for name in ("detector_specs", "routing_fast_specs", "routing_full_specs"):
            state[name] = tuple({"name": spec.name, "options": dict(spec.options)} for spec in getattr(self, name))
        # derived only in PII mode (re-shared on load); a map kept after a replace() to another mode is data
        if self.ner_mode == 'pii' and any(self.gliner_label_map is m for m in _PII_MAPS.values()):
            state['gliner_label_map'] = None
        return state

    def __getstate__(self):
        # Restore the exact normalized state; never re-run __post_init__.
        state = self._plain_state()
        for name in ("detector_specs", "routing_fast_specs", "routing_full_specs"):
            state[name] = getattr(self, name)
        frozen = [k for k, v in self.__dict__.items() if isinstance(v, MappingProxyType) and state[k] is not None]
        return state, frozen

    def __setstate__(self, packed):
        state, frozen = packed
        for key, value in state.items():
            if key in frozen:
                value = MappingProxyType(value)
            object.__setattr__(self, key, value)
        if self.ner_mode == 'pii' and self.gliner_label_map is None:
            object.__setattr__(self, 'gliner_label_map', _PII_MAPS[self.legacy_type_names])


_USER_LABEL = re.compile(LABEL_PATTERN)


def _user_terms(name, terms):
    if isinstance(terms, (str, bytes)) or not isinstance(terms, Iterable):
        raise ValueError(f"{name} must be a tuple of strings, got {terms!r}")
    terms = tuple(terms)
    for term in terms:
        if not isinstance(term, str) or not term.strip():
            raise ValueError(f"{name} terms must be non-empty strings, got {term!r}")
    return terms


def _user_label(name, label):
    if not isinstance(label, str) or not _USER_LABEL.fullmatch(label):
        raise ValueError(f"{name} labels must be upper case (A-Z, 0-9, _; starting with a letter), "
                         f"such as 'PROJECT', got {label!r}")


def _validate_user_terms(cfg):
    """Validate and freeze custom_deny_terms, custom_allow_terms and custom_patterns."""
    import regex
    if not isinstance(cfg.custom_terms_case_sensitive, bool):
        raise ValueError(f"custom_terms_case_sensitive must be a bool, got {cfg.custom_terms_case_sensitive!r}")
    object.__setattr__(cfg, 'custom_allow_terms', _user_terms('custom_allow_terms', cfg.custom_allow_terms or ()))
    if cfg.custom_deny_terms is not None:
        if not isinstance(cfg.custom_deny_terms, Mapping):
            raise ValueError(f"custom_deny_terms must be a mapping {{LABEL: (term, ...)}}, got {cfg.custom_deny_terms!r}")
        deny = {}
        seen: dict[str, str] = {}
        for label, terms in cfg.custom_deny_terms.items():
            _user_label('custom_deny_terms', label)
            deny[label] = _user_terms(f'custom_deny_terms[{label!r}]', terms)
            if not deny[label]:
                raise ValueError(f"custom_deny_terms[{label!r}] has no terms; drop the label or add a term")
            for term in deny[label]:
                key = term if cfg.custom_terms_case_sensitive else term.casefold()
                if seen.setdefault(key, label) != label:
                    raise ValueError(f"custom_deny_terms: {term!r} is listed under both {seen[key]!r} and {label!r}")
        object.__setattr__(cfg, 'custom_deny_terms', MappingProxyType(deny))
    timeout = cfg.custom_patterns_timeout
    if timeout is not None and (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                                or not 0 < timeout < float('inf')):
        raise ValueError(f"custom_patterns_timeout must be a positive number of seconds or None, got {timeout!r}")
    if cfg.custom_patterns_on_timeout not in get_args(OnPatternTimeout):
        raise ValueError(f"custom_patterns_on_timeout must be 'raise' or 'warn', got {cfg.custom_patterns_on_timeout!r}")
    if cfg.custom_patterns is not None:
        if not isinstance(cfg.custom_patterns, Mapping):
            raise ValueError(f"custom_patterns must be a mapping {{LABEL: regex}}, got {cfg.custom_patterns!r}")
        for label, pattern in cfg.custom_patterns.items():
            _user_label('custom_patterns', label)
            if not isinstance(pattern, str) or not pattern:
                raise ValueError(f"custom_patterns[{label!r}] must be a non-empty regex string, got {pattern!r}")
            try:
                compiled = regex.compile(pattern)
            except regex.error as error:
                raise ValueError(f"custom_patterns[{label!r}] is not a valid regex: {error}") from None
            # shortcut: probes a few texts for an empty match, not every text; the step also skips empty matches.
            if any(m.group() == '' for probe in ('', ' ', 'a', '0', 'a b', 'A-1.') for m in compiled.finditer(probe)):
                raise ValueError(f"custom_patterns[{label!r}] can match the empty string: {pattern!r}")
        object.__setattr__(cfg, 'custom_patterns', MappingProxyType(dict(cfg.custom_patterns)))


def _apply_gliclass_defaults(cfg):
    if cfg.gliclass_onnx:
        raise ValueError(
            "GLiClass ONNX is not supported by the gliclass package. "
            "Use gliclass_onnx=False."
        )
    if (
        cfg.gliclass_model in (None, GLICLASS_DEFAULT_MODEL)
        and cfg.gliclass_revision is None
    ):
        object.__setattr__(
            cfg,
            'gliclass_revision',
            GLICLASS_DEFAULT_REVISION,
        )


def _freeze_sequences(cfg):
    """Tuple the list-typed fields and check the custom steps."""
    # Convert mutable collections to immutable for frozen safety
    if isinstance(cfg.positional_tags, list):
        object.__setattr__(cfg, 'positional_tags', tuple(cfg.positional_tags))
    if isinstance(cfg.custom_pipeline_steps, list):
        object.__setattr__(cfg, 'custom_pipeline_steps', tuple(cfg.custom_pipeline_steps))
    for step in cfg.custom_pipeline_steps:
        if not callable(step):
            raise ValueError(
                f"custom_pipeline_steps must contain callables, got: {type(step)!r}"
            )


def _validate_modes(cfg):
    # --- NER mode + replacement mode validation ---
    if cfg.ner_mode not in VALID_NER_MODES:
        raise ValueError(
            f"ner_mode must be one of {sorted(VALID_NER_MODES)}, got: {cfg.ner_mode!r}"
        )
    if cfg.replacement_mode not in VALID_REPLACEMENT_MODES:
        raise ValueError(
            f"replacement_mode must be one of {sorted(VALID_REPLACEMENT_MODES)}, "
            f"got: {cfg.replacement_mode!r}"
        )
    if cfg.json_key_cleaning not in VALID_JSON_KEY_CLEANING:
        raise ValueError(
            f"json_key_cleaning must be one of {sorted(VALID_JSON_KEY_CLEANING)}, "
            f"got: {cfg.json_key_cleaning!r}"
        )
    if (
        cfg.replacement_mode == 'reversible'
        and cfg.check_fuzzy_replace_dates
    ):
        raise ValueError(
            "reversible mode does not support fuzzy date replacement"
        )


def _apply_pii_defaults(cfg):
    # PII mode auto-configuration: sets GLiNER defaults for PII detection.
    # User-provided values take priority (checked via default comparisons).
    if cfg.ner_mode == 'pii':
        if cfg.ner_backend == 'onnx':
            object.__setattr__(cfg, 'ner_backend', 'gliner')
            # Use ONNX-loaded GLiNER when available (pre-built ONNX on Hub)
            if not cfg.gliner_onnx:
                object.__setattr__(cfg, 'gliner_onnx', True)
        if not cfg.gliner_model:
            object.__setattr__(cfg, 'gliner_model', PII_DEFAULT_MODEL)
        if (
            cfg.gliner_model == PII_DEFAULT_MODEL
            and cfg.gliner_revision is None
        ):
            object.__setattr__(
                cfg,
                'gliner_revision',
                PII_DEFAULT_REVISION,
            )
        if cfg.gliner_labels == ('person', 'organization', 'location'):
            object.__setattr__(cfg, 'gliner_labels', PII_LABELS)
        pii_tags = set(cfg.positional_tags)
        # Derived maps are shared objects, so a dataclasses.replace() clone re-derives them
        # (and drops the other naming's phone/IP tags) when legacy_type_names changes.
        if cfg.gliner_label_map is _PII_MAPS[True] or cfg.gliner_label_map is _PII_MAPS[False]:
            pii_tags -= {'PHONE', 'IP', 'PHONE_NUMBER', 'IP_ADDRESS'}
            object.__setattr__(cfg, 'gliner_label_map', None)
        if cfg.gliner_label_map is None:
            object.__setattr__(cfg, 'gliner_label_map', _PII_MAPS[cfg.legacy_type_names])
        # Expand positional_tags to include all PII label tags
        for label in cfg.gliner_labels:
            pii_tags.add(cfg.gliner_label_map.get(label, label.upper()))
        object.__setattr__(cfg, 'positional_tags', tuple(sorted(pii_tags)))


def _validate_ner_settings(cfg):
    """Runs after _apply_pii_defaults, which can change ner_backend."""
    # --- NER backend validation ---
    if cfg.ner_backend not in VALID_NER_BACKENDS:
        raise ValueError(
            f"ner_backend must be one of {sorted(VALID_NER_BACKENDS)}, "
            f"got: {cfg.ner_backend!r}"
        )

    # ner_batch_size must be positive
    if cfg.ner_batch_size <= 0:
        raise ValueError(
            f"ner_batch_size must be >= 1, got {cfg.ner_batch_size}"
        )
    for name in ('onnx_intra_op_threads', 'onnx_inter_op_threads'):
        value = getattr(cfg, name)
        if value is not None and value < 1:
            raise ValueError(f"{name} must be None or >= 1, got {value}")
    if cfg.ner_chunk_overlap < 0:
        raise ValueError(f"ner_chunk_overlap must be >= 0, got {cfg.ner_chunk_overlap}")
    if cfg.ner_device not in (None, 'cpu', 'cuda', 'mps'):
        raise ValueError(f"ner_device must be None, 'cpu', 'cuda' or 'mps', got {cfg.ner_device!r}")
    if cfg.cuda_device_id < 0:
        raise ValueError(f"cuda_device_id must be >= 0, got {cfg.cuda_device_id}")
    if cfg.onnx_cuda_provider_options is not None:
        object.__setattr__(cfg, 'onnx_cuda_provider_options',
                           MappingProxyType(dict(cfg.onnx_cuda_provider_options)))
    for name in ('ner_confidence_threshold', 'gliner_threshold'):
        value = getattr(cfg, name)
        if value is not None and not 0.0 <= value <= 1.0:
            raise ValueError(f"{name} must be None or in [0, 1], got {value}")
    if cfg.ner_ensemble_vote not in get_args(NerEnsembleVote):
        raise ValueError(f"ner_ensemble_vote must be 'max' or 'mean', got {cfg.ner_ensemble_vote!r}")
    if cfg.replace_numbers_mode not in get_args(ReplaceNumbersMode):
        raise ValueError(f"replace_numbers_mode must be 'identifiers' or 'all', got {cfg.replace_numbers_mode!r}")
    if isinstance(cfg.replace_numbers_min_digits, bool) or not isinstance(cfg.replace_numbers_min_digits, int) \
            or cfg.replace_numbers_min_digits < 1:
        raise ValueError(f"replace_numbers_min_digits must be an int >= 1, got {cfg.replace_numbers_min_digits!r}")
    if cfg.ner_merge_location_gap < 0:
        raise ValueError(f"ner_merge_location_gap must be >= 0, got {cfg.ner_merge_location_gap}")
    if cfg.ner_propagate_min_score is not None and not 0.0 <= cfg.ner_propagate_min_score <= 1.0:
        raise ValueError(f"ner_propagate_min_score must be None or in [0, 1], got {cfg.ner_propagate_min_score}")
    if cfg.ner_subword_widen is not None and cfg.ner_subword_widen < 0:
        raise ValueError(f"ner_subword_widen must be None or >= 0, got {cfg.ner_subword_widen}")
    for name in ('language_confidence_warning', 'language_margin_warning'):
        value = getattr(cfg, name)
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"{name} must be in [0, 1], got {value}")


def _validate_gliner(cfg):
    """Require the GLiNER fields the backend needs and freeze its maps."""
    # GLiNER fields required for gliner/ensemble backends
    needs_gliner = cfg.ner_backend in GLINER_BACKENDS
    if needs_gliner:
        if not cfg.gliner_model:
            raise ValueError(
                f"gliner_model is required when ner_backend='{cfg.ner_backend}'. "
                f"Provide a HuggingFace model ID (e.g. 'urchade/gliner_large-v2.1')."
            )
        if cfg.gliner_variant not in ('gliner', 'gliner2'):
            raise ValueError(
                f"gliner_variant must be 'gliner' or 'gliner2', "
                f"got: {cfg.gliner_variant!r}"
            )

    # Freeze gliner_label_map
    if cfg.gliner_label_map is not None and not any(cfg.gliner_label_map is m for m in _PII_MAPS.values()):
        object.__setattr__(cfg, 'gliner_label_map',
                           MappingProxyType(dict(cfg.gliner_label_map)))

    # Freeze gliner_label_descriptions
    if cfg.gliner_label_descriptions is not None:
        object.__setattr__(cfg, 'gliner_label_descriptions',
                           MappingProxyType(dict(cfg.gliner_label_descriptions)))


def _reconcile_torch_models(cfg):
    # Reconcile torch_ner_models
    if cfg.torch_ner_models is not None:
        missing = REQUIRED_NER_KEYS - set(cfg.torch_ner_models)
        if missing:
            raise ValueError(
                f"torch_ner_models must include {sorted(REQUIRED_NER_KEYS)}, "
                f"missing: {sorted(missing)}"
            )
        merged = {**DEFAULT_TORCH_NER_MODELS, **cfg.torch_ner_models}
        object.__setattr__(cfg, 'torch_ner_models', MappingProxyType(merged))
    elif cfg.ner_backend in TORCH_BACKENDS:
        object.__setattr__(cfg, 'torch_ner_models',
                           MappingProxyType(dict(DEFAULT_TORCH_NER_MODELS)))
    if cfg.torch_ner_models is not None:
        torch_revisions = {
            key: revision
            for key, revision in DEFAULT_TORCH_NER_REVISIONS.items()
            if cfg.torch_ner_models.get(key) == DEFAULT_TORCH_NER_MODELS.get(key)
        }
        if cfg.torch_ner_model_revisions is not None:
            torch_revisions.update(cfg.torch_ner_model_revisions)
        object.__setattr__(
            cfg,
            'torch_ner_model_revisions',
            MappingProxyType(torch_revisions),
        )


def _reconcile_ner_models(cfg):
    if cfg.ner_models is None:
        merged = dict(_DEFAULT_CONFIG_NER_MODELS)
    else:
        missing = REQUIRED_NER_KEYS - set(cfg.ner_models)
        if missing:
            raise ValueError(
                f"ner_models must include {sorted(REQUIRED_NER_KEYS)}, "
                f"missing: {sorted(missing)}"
            )
        # A copied default config keeps its four-language routing.
        merged = (
            dict(cfg.ner_models) if cfg.ner_models == _DEFAULT_CONFIG_NER_MODELS
            else {**DEFAULT_NER_MODELS, **cfg.ner_models}
        )
    object.__setattr__(cfg, 'ner_models', MappingProxyType(merged))

    pinned_revisions = {
        key: revision
        for key, revision in DEFAULT_NER_REVISIONS.items()
        if cfg.ner_models.get(key) == DEFAULT_NER_MODELS.get(key)
    }
    if cfg.ner_model_revisions is not None:
        pinned_revisions.update(cfg.ner_model_revisions)
    object.__setattr__(
        cfg,
        'ner_model_revisions',
        MappingProxyType(pinned_revisions),
    )


def _resolve_languages(cfg):
    """Canonicalise the language fields and freeze their maps."""
    # --- Language validation and supported_languages computation ---
    # Resolve language (str or tuple of str) via ISO code / name lookup
    if cfg.language is not None:
        if isinstance(cfg.language, str):
            object.__setattr__(cfg, 'language', resolve_language(cfg.language))
        elif isinstance(cfg.language, (list, tuple)):
            resolved = tuple(resolve_language(lang) for lang in cfg.language)
            object.__setattr__(cfg, 'language', resolved)

    # Coerce extra_languages to tuple and resolve each entry
    if isinstance(cfg.extra_languages, list):
        object.__setattr__(cfg, 'extra_languages', tuple(cfg.extra_languages))
    if cfg.extra_languages:
        resolved_extra = tuple(resolve_language(lang) for lang in cfg.extra_languages)
        object.__setattr__(cfg, 'extra_languages', resolved_extra)

    # Validate and freeze custom_stopwords (keys must be valid language names)
    if cfg.custom_stopwords:
        resolved_sw = {resolve_language(k): frozenset(v) for k, v in cfg.custom_stopwords.items()}
        object.__setattr__(cfg, 'custom_stopwords',
                           MappingProxyType(resolved_sw))

    if cfg.date_builtin_month_languages is not None:
        from sct.utils.constants import MONTH_NAMES_MULTILINGUAL
        codes = tuple(cfg.date_builtin_month_languages)
        unknown = set(codes) - set().union(*MONTH_NAMES_MULTILINGUAL.values())
        if isinstance(cfg.date_builtin_month_languages, str) or unknown:
            raise ValueError(f"date_builtin_month_languages must be a tuple of built-in month ISO codes, "
                             f"got {cfg.date_builtin_month_languages!r}")
        object.__setattr__(cfg, 'date_builtin_month_languages', codes)

    # Validate and freeze custom_month_names
    if cfg.custom_month_names:
        resolved_mn = {resolve_language(k): tuple(v) for k, v in cfg.custom_month_names.items()}
        object.__setattr__(cfg, 'custom_month_names',
                           MappingProxyType(resolved_mn))


def _compute_supported_languages(cfg):
    # Compute supported_languages: union of all sources
    langs = set(DEFAULT_LANGUAGES)
    langs.update(cfg.extra_languages)
    # Add ner_models keys (minus MULTILINGUAL — it's a model, not a spoken language)
    if cfg.ner_models:
        langs.update(k for k in cfg.ner_models if k != 'MULTILINGUAL')
    if cfg.custom_stopwords:
        langs.update(cfg.custom_stopwords.keys())
    if cfg.custom_month_names:
        langs.update(cfg.custom_month_names.keys())
    # Add languages from tuple-of-languages config
    if isinstance(cfg.language, tuple):
        langs.update(cfg.language)
    # Any Lingua language is a valid pin (resolve_language raised above otherwise);
    # supported_languages only means "has stopwords/dates/NER key".
    object.__setattr__(cfg, 'supported_languages', frozenset(langs))


def require_adapter_mode(cfg: TextCleanerConfig) -> None:
    """Refuse reversible mode on a surface that has no way to hand back each text's map."""
    if cfg.replacement_mode == "reversible":
        raise ValueError(
            "Adapters do not support reversible mode. "
            "Process each text directly and retain its token map."
        )
