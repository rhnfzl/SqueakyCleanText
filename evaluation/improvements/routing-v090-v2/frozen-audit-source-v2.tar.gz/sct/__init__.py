"""SqueakyCleanText - Text cleaning and preprocessing pipeline for ML/NLP."""

from sct.config import TextCleanerConfig, PII_LABELS, PII_LABEL_MAP
from sct.detectors import Detector, DetectorCapabilities, DetectorRegistry, DetectorSpec, DetectorUnavailable
from sct.policy_v2 import UnifiedPrivacyPolicy, HandlingRule, FindingDecision
from sct.documents import (
    DocumentElement, DocumentExtractor, ExtractedDocument, ProcessedDocument, clean_document, extract_document,
)
from sct.findings import Detection, DetectionContext, TextRange
from sct.schema import FieldRule, FieldSchema
from sct.privacy import (
    DetectedEntity,
    EntityFinding,
    EntityRule,
    InMemoryTokenStore,
    PrivacyPolicy,
    ProcessingMetrics,
    TokenStore,
)
from sct.sct import CustomPatternTimeout, TextCleaner
from sct.utils.ner import ModelLoadError
from sct.presets import PRESETS, preset_config
from sct.adapters import (
    DataFrameResult,
    PathFinding,
    PathFindingV2,
    ProcessedRAGChunk,
    RAGChunk,
    StructuredResult,
    process_dataframe,
    process_json,
    process_rag_chunks,
)
from sct.browser import build_browser_manifest, write_browser_manifest
from sct.model_benchmark import (
    AdoptionDecision,
    LatencyMetrics,
    ModelBenchmark,
    assess_candidate,
    candidate_config,
    run_model_benchmark,
)
from sct.model_candidates import MODEL_CANDIDATES, ModelCandidate
from sct.ocr import (
    ImageRedactionResult,
    OCRSpan,
    TesseractOCRProvider,
    redact_image,
    select_redaction_regions,
)
from sct.risk import (
    ReidentificationRiskReport,
    assess_reidentification_risk,
)
from sct.streaming import (
    BufferedStreamingRedactor,
    WindowedStreamingRedactor,
)
from sct.utils.anonymization_map import AnonymizationMap, MapEntry
from sct.utils.process_result import ProcessResult

__version__ = "0.9.0"
__all__ = [
    "DocumentElement", "DocumentExtractor", "ExtractedDocument", "ProcessedDocument", "clean_document", "extract_document",
    "UnifiedPrivacyPolicy", "HandlingRule", "FindingDecision", "Detection", "DetectionContext", "TextRange",
    "Detector", "DetectorCapabilities", "DetectorRegistry", "DetectorSpec", "DetectorUnavailable",
    "TextCleaner", "TextCleanerConfig", "CustomPatternTimeout", "ModelLoadError", "PRESETS", "preset_config",
    "PII_LABELS", "PII_LABEL_MAP",
    "AnonymizationMap", "MapEntry", "ProcessResult",
    "DetectedEntity", "EntityFinding", "EntityRule",
    "PrivacyPolicy", "ProcessingMetrics",
    "TokenStore", "InMemoryTokenStore",
    "FieldRule", "FieldSchema", "PathFindingV2",
    "DataFrameResult", "PathFinding", "ProcessedRAGChunk",
    "RAGChunk", "StructuredResult",
    "process_dataframe", "process_json", "process_rag_chunks",
    "build_browser_manifest", "write_browser_manifest",
    "AdoptionDecision", "LatencyMetrics", "ModelBenchmark",
    "assess_candidate", "candidate_config", "run_model_benchmark",
    "MODEL_CANDIDATES", "ModelCandidate",
    "ImageRedactionResult", "OCRSpan", "TesseractOCRProvider",
    "redact_image", "select_redaction_regions",
    "ReidentificationRiskReport", "assess_reidentification_risk",
    "BufferedStreamingRedactor", "WindowedStreamingRedactor",
]
